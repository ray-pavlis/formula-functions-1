// Fahrenheit to Celsius Convertor

// Event Listener
document.getElementById("convert-btn").addEventListener("click", convertFahrToCels);

// Event Function
function convertFahrToCels() {
    // INPUT
    let fahrTemp = document.getElementById("input").value;
    
    // PROCESS
    let celsTemp = (fahrTemp - 32) * 5 / 9;

    // OUTPUT
    document.getElementById("results").innerHTML = celsTemp;
}